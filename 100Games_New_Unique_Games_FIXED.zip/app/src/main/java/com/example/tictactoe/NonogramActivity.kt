package com.example.tictactoe

import android.os.Bundle
import android.widget.LinearLayout

/** لغز صورة منطقية 5×5؛ استخدم أدلة الصفوف والأعمدة لإظهار شكل القلب. */
class NonogramActivity:BaseGameActivity(){
 override val gameTitle="لغز الصورة المخفية"
 private val solution= listOf("01110","11111","11111","01110","00100")
 private val marks=Array(5){IntArray(5)};private lateinit var board:LinearLayout;private lateinit var info:android.widget.TextView
 override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);initScreen(gameTitle);info=label("املأ المربعات لتكوين قلب. الأرقام أعلى وأسفل كل صف تشير إلى مجموعات الخانات المتجاورة.",14f);content.addView(info,lp(bottom=8));content.addView(label("الأعمدة: 2 | 5 | 5 | 3 | 2",14f),lp(bottom=4));board=LinearLayout(this);board.orientation=LinearLayout.VERTICAL;content.addView(board,lp());content.addView(button("مسح اللوحة",false){for(y in 0..4)marks[y].fill(0);draw()},lp(top=10));draw()}
 private fun tap(x:Int,y:Int){marks[y][x]=(marks[y][x]+1)%3;draw()}
 private fun draw(){board.removeAllViews();for(y in 0..4){val r=row();r.addView(label(listOf("1 3 1","5","5","3","1")[y],12f),LinearLayout.LayoutParams(dp(38),dp(44)));for(x in 0..4){val s=when(marks[y][x]){1->"🟦";2->"❌";else->"⬜"};r.addView(button(s,false){tap(x,y)},LinearLayout.LayoutParams(0,dp(44),1f))};board.addView(r,lp())};if((0..4).all{y->(0..4).all{x->(marks[y][x]==1)==(solution[y][x]=='1')})info.text="صحيح! اكتشفت الصورة المخفية ❤️"}
}
