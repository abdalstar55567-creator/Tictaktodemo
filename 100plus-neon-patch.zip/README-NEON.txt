إضافة لعبة Neon (نيون: معارك الفضاء) إلى 100+
================================================
التطبيق من جذر المستودع:   unzip -o 100plus-neon-patch.zip -d .
ثم:  ./gradlew assembleDebug   (أو ادفع إلى GitHub ليبني Actions الـ APK)

ملفات موجودة تُستبدل (عُدّلت أسطر قليلة فقط، قارنها بـ git diff):
- app/build.gradle            (+ مكتبة androidx.compose.material:material:1.6.2)
- app/src/main/AndroidManifest.xml  (+ نشاط NeonGameActivity)
- .../tictactoe/Games.kt      (+ سطر اللعبة)
- .../tictactoe/MenuActivity.kt و GameMusic.kt  (+ تصنيف الحركة والموسيقى)
- THIRD_PARTY_NOTICES.md      (+ إسناد Neon)
ملفات جديدة: app/src/main/java/com/zero/neon/** ، موارد neon_* ، NEON-LICENSE.txt

المصدر: https://github.com/mariodujic/Neon  — ترخيص MIT © 2022 Mario Dujić
لم يُبنَ المشروع هنا (لا يوجد Android SDK)؛ راجع نتيجة البناء قبل النشر.
