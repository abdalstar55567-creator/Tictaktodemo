package com.example.tictactoe

import android.graphics.Color
import android.content.Context

object GameTheme {
    data class ThemeColors(
        val backgroundColor: Int,
        val boardColor: Int,
        val textColor: Int,
        val cellColor: Int
    )

    // ثيم داكن عصري (Dark Neon / Modern)
    val darkTheme = ThemeColors(
        backgroundColor = Color.parseColor("#121212"),
        boardColor = Color.parseColor("#1E1E1E"),
        textColor = Color.parseColor("#FFFFFF"),
        cellColor = Color.parseColor("#2D2D2D")
    )

    // ثيم كلاسيكي مضيء (Light Theme)
    val lightTheme = ThemeColors(
        backgroundColor = Color.parseColor("#F5F5F5"),
        boardColor = Color.parseColor("#E0E0E0"),
        textColor = Color.parseColor("#212121"),
        cellColor = Color.parseColor("#FFFFFF")
    )

    // دالة مساعدة لتطبيق الثيم الحالي بناءً على تفضيل المستخدم
    fun getTheme(isDarkMode: Boolean): ThemeColors {
        return if (isDarkMode) darkTheme else lightTheme
    }
}
