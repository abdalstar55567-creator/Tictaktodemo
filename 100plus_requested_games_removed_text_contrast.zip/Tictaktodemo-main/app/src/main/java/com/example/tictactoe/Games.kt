package com.example.tictactoe

data class GameInfo(val emoji: String, val title: String, val cls: Class<*>)

/**
 * قائمة الألعاب. لإضافة لعبة جديدة: أنشئ Activity جديدة ترث BaseGameActivity،
 * وسجّلها في AndroidManifest.xml، ثم أضف سطراً هنا.
 */
object Games {
    val all: List<GameInfo> = listOf(
        GameInfo("❌⭕", "إكس أو", MainActivity::class.java),
        GameInfo("🧠", "لعبة الذاكرة", MemoryActivity::class.java),
        GameInfo("🔢", "تخمين الرقم", GuessNumberActivity::class.java),
        GameInfo("✊✋✌️", "حجر ورقة مقص", RpsActivity::class.java),
        GameInfo("➕", "تحدي الحساب", MathActivity::class.java),
        GameInfo("🐹", "اضرب الخلد", WhackActivity::class.java),
        GameInfo("🏃", "الركض السريع", SprintRunActivity::class.java),
        GameInfo("👆", "سرعة الضغط", TapSpeedActivity::class.java),
        GameInfo("⚡", "سرعة رد الفعل", ReactionActivity::class.java),
        GameInfo("🔢", "تحدي الأرقام والصور", PuzzleActivity::class.java),
        GameInfo("🎲", "رمي النرد", DiceActivity::class.java),
        GameInfo("🎨", "تحدي الألوان", ColorMatchActivity::class.java),
        GameInfo("🐍", "الثعبان", SnakeActivity::class.java),
        GameInfo("🔴", "لعبة سيمون", SimonActivity::class.java),
        GameInfo("🔵", "أربعة في صف", Connect4Activity::class.java),
        GameInfo("🔤", "حبل المشنقة", HangmanActivity::class.java),
        GameInfo("🔢", "لعبة 2048", Game2048Activity::class.java),
        GameInfo("🧩", "رتّب الحروف", ScrambleActivity::class.java),
        GameInfo("❓", "أسئلة عامة", TriviaActivity::class.java),
        GameInfo("⬆⬇", "أعلى أم أقل؟", HigherLowerActivity::class.java),
        GameInfo("🎯", "ابحث عن المختلف", OddOneActivity::class.java),
        GameInfo("🔟", "رتّب الأرقام", NumberOrderActivity::class.java),
        GameInfo("🧠", "ذاكرة الأرقام", NumberMemoryActivity::class.java),
        GameInfo("🏗️", "برج الصناديق", TowerActivity::class.java),
        GameInfo("🐤", "الطائر الطائر", FlappyActivity::class.java),
        GameInfo("🧺", "التقط الفواكه", CatchActivity::class.java),
        GameInfo("🚀", "تفادى القنابل", DodgeActivity::class.java),
        GameInfo("🧱", "كسر الطوب", BrickActivity::class.java),
        GameInfo("💣", "كاسحة الألغام", MinesweeperActivity::class.java),
        GameInfo("💡", "أطفئ الأضواء", LightsOutActivity::class.java),
        GameInfo("🎚️", "أوقف المؤشر", StopBarActivity::class.java),
        GameInfo("🌍", "تحدي العواصم", CapitalQuizActivity::class.java),
        GameInfo("🐾", "أصوات الحيوانات", AnimalQuizActivity::class.java),
        GameInfo("🤔", "صح أم خطأ", TrueFalseActivity::class.java),
        GameInfo("🧠", "أكمل المتتالية", SequenceActivity::class.java),
        GameInfo("🎨", "اختبار الألوان", ColorQuizActivity::class.java),
        GameInfo("🔤", "خلط الكلمات", WordScrambleActivity::class.java),
        GameInfo("⚡", "الحساب السريع", QuickMathActivity::class.java),
        GameInfo("🧱", "تيترس", TetrisActivity::class.java),
        GameInfo("☄️", "صيد النيازك", MeteorShootingActivity::class.java),
        GameInfo("🚀", "مدافع الفضاء", SpaceShooterActivity::class.java),
        GameInfo("🗼", "أبراج هانوي", HanoiActivity::class.java),
        GameInfo("🔐", "فك الشفرة", MastermindActivity::class.java),
        GameInfo("🪵", "تحدي الأعواد", NimStrategyActivity::class.java),
        GameInfo("🧠", "ذاكرة الأزواج", MemoryPairsPlusActivity::class.java),
        GameInfo("🎨", "تلوين الحروف", LetterColoringActivity::class.java),
        GameInfo("🧩", "تجميع الصور", PicturePuzzleActivity::class.java),
        GameInfo("🦆", "صيد البط", DuckHuntActivity::class.java),
        GameInfo("🔢", "السودوكو", SudokuActivity::class.java),
        GameInfo("🏰", "منجنيق الكرات", CatapultActivity::class.java),
        GameInfo ("🙃🙂", "جد الاختلاف",  RealisticDifferencesActivity::class.java), 
        GameInfo("🐸", "نطّة الضفدع", FrogHopActivity::class.java),
        GameInfo("♟️", "الداما", CheckersActivity::class.java),
        GameInfo("🌀", "تشابك الألوان (Tangler)", com.andrzejn.tangler.AndroidLauncher::class.java),
        GameInfo("🛸", "نيون: معارك الفضاء", com.zero.neon.NeonGameActivity::class.java),

    )
}
