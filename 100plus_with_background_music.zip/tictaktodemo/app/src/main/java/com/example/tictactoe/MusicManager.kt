package com.example.tictactoe

import android.content.Context
import android.media.MediaPlayer

/**
 * مشغل موسيقى خلفية محلية أصلية مولّدة خصيصاً للتطبيق.
 * لا يحتاج إلى إنترنت ولا يطلب أي صلاحيات.
 */
object MusicManager {
    private const val PREFS = "xozoom_music"
    private const val KEY_ENABLED = "music_enabled"
    private var player: MediaPlayer? = null
    private var currentTrack: Int = 0

    fun enabled(context: Context): Boolean =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_ENABLED, true)

    fun setEnabled(context: Context, enabled: Boolean) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putBoolean(KEY_ENABLED, enabled).apply()
        if (!enabled) stop() else play(context, context.javaClass.simpleName)
    }

    private fun trackFor(activityName: String): Int {
        val action = listOf("Run", "Race", "Flappy", "Frog", "Meteor", "Ghost", "Shooter",
            "Duck", "Football", "Brick", "Hurdle", "Catapult", "Pong", "Basket", "Whack")
        val puzzle = listOf("Puzzle", "Sudoku", "Minesweeper", "Hanoi", "Tower", "Sokoban",
            "Nonogram", "Mastermind", "Pipe", "River", "LightsOut", "Peg")
        return when {
            action.any { activityName.contains(it, true) } -> R.raw.music_action
            puzzle.any { activityName.contains(it, true) } -> R.raw.music_puzzle
            else -> R.raw.music_casual
        }
    }

    fun play(context: Context, activityName: String) {
        if (!enabled(context)) return
        val track = trackFor(activityName)
        if (player != null && currentTrack == track) {
            if (player?.isPlaying == false) try { player?.start() } catch (_: Exception) {}
            return
        }
        stop()
        try {
            player = MediaPlayer.create(context.applicationContext, track)?.apply {
                isLooping = true
                setVolume(0.32f, 0.32f)
                setOnErrorListener { mp, _, _ ->
                    try { mp.release() } catch (_: Exception) {}
                    player = null
                    true
                }
                start()
            }
            currentTrack = track
        } catch (_: Exception) {
            stop()
        }
    }

    fun pause() {
        try { if (player?.isPlaying == true) player?.pause() } catch (_: Exception) {}
    }

    fun stop() {
        try { player?.stop() } catch (_: Exception) {}
        try { player?.release() } catch (_: Exception) {}
        player = null
        currentTrack = 0
    }
}
