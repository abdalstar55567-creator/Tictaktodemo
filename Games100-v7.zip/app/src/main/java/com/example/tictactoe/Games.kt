package com.example.tictactoe

data class GameInfo(val emoji: String, val title: String, val cls: Class<*>)

/**
 * قائمة الألعاب. لإضافة لعبة جديدة: أنشئ Activity جديدة ترث BaseGameActivity،
 * وسجّلها في AndroidManifest.xml، ثم أضف سطراً هنا.
 */
object Games {
    val all: List<GameInfo> = listOf(
        GameInfo("❌⭕", "إكس أو", MainActivity::class.java),
        GameInfo("🧠", "لعبة الذاكرة", MemoryActivity::class.java),
        GameInfo("🔢", "تخمين الرقم", GuessNumberActivity::class.java),
        GameInfo("✊✋✌️", "حجر ورقة مقص", RpsActivity::class.java),
        GameInfo("➕", "تحدي الحساب", MathActivity::class.java),
        GameInfo("🐹", "اضرب الخلد", WhackActivity::class.java),
        GameInfo("👆", "سرعة الضغط", TapSpeedActivity::class.java),
        GameInfo("⚡", "سرعة رد الفعل", ReactionActivity::class.java),
        GameInfo("🧩", "لغز الأرقام", PuzzleActivity::class.java),
        GameInfo("🎲", "رمي النرد", DiceActivity::class.java),
        GameInfo("🎨", "تحدي الألوان", ColorMatchActivity::class.java),
        GameInfo("🐍", "الثعبان", SnakeActivity::class.java),
        GameInfo("🔴", "لعبة سيمون", SimonActivity::class.java),
        GameInfo("🔵", "أربعة في صف", Connect4Activity::class.java),
        GameInfo("🔤", "حبل المشنقة", HangmanActivity::class.java),
        GameInfo("🔢", "لعبة 2048", Game2048Activity::class.java),
        GameInfo("🧩", "رتّب الحروف", ScrambleActivity::class.java),
        GameInfo("❓", "أسئلة عامة", TriviaActivity::class.java),
        GameInfo("⬆⬇", "أعلى أم أقل؟", HigherLowerActivity::class.java),
        GameInfo("🎯", "ابحث عن المختلف", OddOneActivity::class.java),
        GameInfo("🔟", "رتّب الأرقام", NumberOrderActivity::class.java),
        GameInfo("🎁", "حظ الصندوق", LuckBoxActivity::class.java),
        GameInfo("🧠", "ذاكرة الأرقام", NumberMemoryActivity::class.java),
        GameInfo("🏃", "سباق الحواجز", HurdleRunActivity::class.java),
        GameInfo("🏗️", "برج الصناديق", TowerActivity::class.java),
        GameInfo("🐤", "الطائر الطائر", FlappyActivity::class.java),
        GameInfo("🧺", "التقط الفواكه", CatchActivity::class.java),
        GameInfo("🚀", "تفادى القنابل", DodgeActivity::class.java),
        GameInfo("🧱", "كسر الطوب", BrickActivity::class.java),
        GameInfo("💣", "كاسحة الألغام", MinesweeperActivity::class.java),
        GameInfo("💡", "أطفئ الأضواء", LightsOutActivity::class.java),
        GameInfo("🎚️", "أوقف المؤشر", StopBarActivity::class.java),
        GameInfo("🪙", "توقّع العملة", CoinFlipActivity::class.java),
        GameInfo("🎲", "مبارزة النرد", DiceDuelActivity::class.java),
        GameInfo("🔢", "زوجي أم فردي", OddEvenActivity::class.java),
        GameInfo("🌍", "تحدي العواصم", CapitalQuizActivity::class.java),
        GameInfo("🐾", "أصوات الحيوانات", AnimalQuizActivity::class.java),
        GameInfo("🤔", "صح أم خطأ", TrueFalseActivity::class.java),
        GameInfo("🧠", "أكمل المتتالية", SequenceActivity::class.java),
        GameInfo("🎨", "اختبار الألوان", ColorQuizActivity::class.java),
        GameInfo("🔤", "خلط الكلمات", WordScrambleActivity::class.java),
        GameInfo("⚡", "الحساب السريع", QuickMathActivity::class.java),
        GameInfo("🏎️", "سباق السيارات", CarRaceActivity::class.java),
        GameInfo("🟡", "متاهة آكل النقاط", PacManActivity::class.java),
        GameInfo("👻", "مطاردة الأشباح", GhostMazeActivity::class.java),
        GameInfo("🚀", "مدافع الفضاء", SpaceShooterActivity::class.java),
        GameInfo("🚴", "سباق الدراجات", BikeRaceActivity::class.java),
        GameInfo("🛶", "مغامرة النهر", RiverRunActivity::class.java),
        GameInfo("🔮", "متاهة الكرة", BallMazeActivity::class.java),
        GameInfo("🌴", "عدّاء الغابة", JungleRunnerActivity::class.java),
        GameInfo("🫧", "جامع الفقاعات", BubbleCatchActivity::class.java),
        GameInfo("🗝️", "الهروب من المتاهة", MazeEscapeActivity::class.java)
    )
}
