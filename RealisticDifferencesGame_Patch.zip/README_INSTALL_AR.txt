ملفات تحديث لعبة اكتشاف الفروقات

المحتويات:
- app/src/main/java/com/example/tictactoe/RealisticDifferencesActivity.kt
- app/src/main/res/drawable/sample_image_2.png

طريقة التركيب:
1. ارفع الملفين إلى المسارات نفسها داخل مستودع Android.
2. احتفظ بالصورة الأصلية الحالية باسم:
   app/src/main/res/drawable/sample_image.png
3. تأكد أن AndroidManifest.xml يحتوي على:
   <activity android:name=".RealisticDifferencesActivity" />
4. هذا النشاط يستخدم Jetpack Compose. إذا لم تكن Compose مفعّلة في app/build.gradle
   أو ظهرت أخطاء unresolved reference: compose / setContent، فعّل Compose وأضف
   مكتبات Compose و activity-compose المتوافقة مع Kotlin 1.9.22.

تسلسل اللعبة:
- تعرض الصورة الأصلية 5 ثوانٍ.
- تعرض الصورة الثانية بعدها.
- يضغط اللاعب على مناطق الفروقات الثلاث.
- تظهر المنطقة المكتشفة بإطار أخضر.
- زر إعادة اللعب يعيد الجولة من البداية.

ملاحظة:
إحداثيات مناطق اللمس نسبية للصورة وليست بالبكسل، حتى تتكيف مع حجم عرض الصورة.
