# تثبيت الألعاب الجديدة

> هذه الحزمة تفترض أن اسم الحزمة (package) في مشروعك هو `com.example.tictactoe`.
> إذا كان مختلفًا، غيّر السطر الأول `package ...` في ملفات `.kt` الأربعة،
> وغيّر اسم الكلاس في `activity_snake.xml` (`com.example.tictactoe.SnakeView`).

## 1) انسخ الملفات
فك الضغط داخل جذر المشروع بحيث تندمج المجلدات `app/src/main/...` مع مشروعك.

## 2) أضف الأنشطة في AndroidManifest.xml
داخل وسم `<application>`:

```xml
<activity android:name=".SnakeActivity" />
<activity android:name=".Game2048Activity" />
<activity android:name=".WhackAMoleActivity" />
```

## 3) أضف الأزرار في res/layout/activity_menu.xml

```xml
<Button
    android:id="@+id/btnSnakeGame"
    android:layout_width="match_parent"
    android:layout_height="wrap_content"
    android:text="لعبة الأفعى 🐍" />

<Button
    android:id="@+id/btn2048Game"
    android:layout_width="match_parent"
    android:layout_height="wrap_content"
    android:text="لعبة 2048 🔢" />

<Button
    android:id="@+id/btnWhackGame"
    android:layout_width="match_parent"
    android:layout_height="wrap_content"
    android:text="اضرب الخلد 🐹" />
```

## 4) اربطها في MenuActivity.kt (داخل onCreate)
تأكد من وجود `import android.content.Intent` و `import android.widget.Button`.

```kotlin
findViewById<Button>(R.id.btnSnakeGame).setOnClickListener {
    startActivity(Intent(this, SnakeActivity::class.java))
}
findViewById<Button>(R.id.btn2048Game).setOnClickListener {
    startActivity(Intent(this, Game2048Activity::class.java))
}
findViewById<Button>(R.id.btnWhackGame).setOnClickListener {
    startActivity(Intent(this, WhackAMoleActivity::class.java))
}
```

## 5) ابنِ المشروع
```
./gradlew assembleDebug
```
