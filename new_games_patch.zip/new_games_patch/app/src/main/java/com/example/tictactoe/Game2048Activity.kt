package com.example.tictactoe

import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.GridLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlin.random.Random

class Game2048Activity : AppCompatActivity() {

    private val size = 4
    private var board = Array(size) { IntArray(size) }
    private lateinit var gridLayout: GridLayout
    private lateinit var scoreText: TextView
    private var score = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_2048)

        gridLayout = findViewById(R.id.grid2048)
        scoreText = findViewById(R.id.tv2048Score)

        findViewById<Button>(R.id.btnUp).setOnClickListener { move(Move.UP) }
        findViewById<Button>(R.id.btnDown).setOnClickListener { move(Move.DOWN) }
        findViewById<Button>(R.id.btnLeft).setOnClickListener { move(Move.LEFT) }
        findViewById<Button>(R.id.btnRight).setOnClickListener { move(Move.RIGHT) }

        addRandomTile()
        addRandomTile()
        updateUI()
    }

    private enum class Move { UP, DOWN, LEFT, RIGHT }

    private fun addRandomTile() {
        val emptyCells = mutableListOf<Pair<Int, Int>>()
        for (i in 0 until size) for (j in 0 until size) if (board[i][j] == 0) emptyCells.add(i to j)
        if (emptyCells.isNotEmpty()) {
            val (i, j) = emptyCells.random()
            board[i][j] = if (Random.nextFloat() < 0.9f) 2 else 4
        }
    }

    /** يدمج سطرًا واحدًا باتجاه البداية ويعيد السطر الجديد. */
    private fun slideLine(line: IntArray): IntArray {
        val nums = line.filter { it != 0 }.toMutableList()
        val result = mutableListOf<Int>()
        var i = 0
        while (i < nums.size) {
            if (i + 1 < nums.size && nums[i] == nums[i + 1]) {
                val merged = nums[i] * 2
                result.add(merged)
                score += merged
                i += 2
            } else {
                result.add(nums[i])
                i++
            }
        }
        while (result.size < size) result.add(0)
        return result.toIntArray()
    }

    private fun move(direction: Move) {
        val newBoard = Array(size) { IntArray(size) }

        for (k in 0 until size) {
            // استخراج السطر أو العمود بحيث تكون البداية هي جهة الحركة
            val line = IntArray(size) { idx ->
                when (direction) {
                    Move.LEFT -> board[k][idx]
                    Move.RIGHT -> board[k][size - 1 - idx]
                    Move.UP -> board[idx][k]
                    Move.DOWN -> board[size - 1 - idx][k]
                }
            }
            val slid = slideLine(line)
            for (idx in 0 until size) {
                when (direction) {
                    Move.LEFT -> newBoard[k][idx] = slid[idx]
                    Move.RIGHT -> newBoard[k][size - 1 - idx] = slid[idx]
                    Move.UP -> newBoard[idx][k] = slid[idx]
                    Move.DOWN -> newBoard[size - 1 - idx][k] = slid[idx]
                }
            }
        }

        val changed = (0 until size).any { i -> (0 until size).any { j -> newBoard[i][j] != board[i][j] } }
        if (!changed) return

        board = newBoard
        addRandomTile()
        updateUI()

        if (board.any { row -> row.any { it == 2048 } }) {
            Toast.makeText(this, "مبروك! وصلت إلى 2048 🎉", Toast.LENGTH_LONG).show()
        } else if (!canMove()) {
            Toast.makeText(this, "انتهت اللعبة! النقاط: $score", Toast.LENGTH_LONG).show()
        }
    }

    private fun canMove(): Boolean {
        for (i in 0 until size) {
            for (j in 0 until size) {
                if (board[i][j] == 0) return true
                if (j + 1 < size && board[i][j] == board[i][j + 1]) return true
                if (i + 1 < size && board[i][j] == board[i + 1][j]) return true
            }
        }
        return false
    }

    private fun tileColor(value: Int): Int = when (value) {
        0 -> 0xFFCDC1B4.toInt()
        2 -> 0xFFEEE4DA.toInt()
        4 -> 0xFFEDE0C8.toInt()
        8 -> 0xFFF2B179.toInt()
        16 -> 0xFFF59563.toInt()
        32 -> 0xFFF67C5F.toInt()
        64 -> 0xFFF65E3B.toInt()
        else -> 0xFFEDCF72.toInt()
    }

    private fun updateUI() {
        gridLayout.removeAllViews()
        for (i in 0 until size) {
            for (j in 0 until size) {
                val value = board[i][j]
                val cell = TextView(this).apply {
                    text = if (value == 0) "" else value.toString()
                    textSize = 24f
                    gravity = Gravity.CENTER
                    setTextColor(if (value <= 4) 0xFF776E65.toInt() else 0xFFFFFFFF.toInt())
                    setBackgroundColor(tileColor(value))
                }
                val params = GridLayout.LayoutParams(
                    GridLayout.spec(i, 1f),
                    GridLayout.spec(j, 1f)
                ).apply {
                    width = 0
                    height = 0
                    setMargins(4, 4, 4, 4)
                }
                gridLayout.addView(cell, params)
            }
        }
        scoreText.text = "النقاط: $score"
    }
}
