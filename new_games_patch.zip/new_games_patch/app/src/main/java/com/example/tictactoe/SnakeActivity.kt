package com.example.tictactoe

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.MotionEvent
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import kotlin.math.abs

class SnakeActivity : AppCompatActivity() {

    private lateinit var snakeView: SnakeView
    private lateinit var scoreText: TextView

    @SuppressLint("ClickableViewAccessibility")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_snake)

        snakeView = findViewById(R.id.snakeView)
        scoreText = findViewById(R.id.tvSnakeScore)

        snakeView.onScoreChanged = { score ->
            scoreText.text = "النقاط: $score"
        }

        // التحكم باللمس (سحب الإصبع)
        snakeView.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    snakeView.startX = event.x
                    snakeView.startY = event.y
                }
                MotionEvent.ACTION_UP -> {
                    val dx = event.x - snakeView.startX
                    val dy = event.y - snakeView.startY
                    if (snakeView.isGameOver) {
                        // لمسة بعد انتهاء اللعبة تعيد التشغيل
                        snakeView.restart()
                        scoreText.text = "النقاط: 0"
                    } else if (abs(dx) > abs(dy)) {
                        if (dx > 0) snakeView.setDirection(SnakeView.Direction.RIGHT)
                        else snakeView.setDirection(SnakeView.Direction.LEFT)
                    } else {
                        if (dy > 0) snakeView.setDirection(SnakeView.Direction.DOWN)
                        else snakeView.setDirection(SnakeView.Direction.UP)
                    }
                }
            }
            true
        }
    }
}
