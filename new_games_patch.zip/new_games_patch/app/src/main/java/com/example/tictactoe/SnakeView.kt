package com.example.tictactoe

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.os.Handler
import android.os.Looper
import android.util.AttributeSet
import android.view.View
import kotlin.random.Random

class SnakeView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {

    enum class Direction { UP, DOWN, LEFT, RIGHT }

    data class Point(val x: Int, val y: Int)

    private val columns = 20

    private var snake = mutableListOf(Point(10, 10), Point(9, 10), Point(8, 10))
    private var food = Point(15, 5)
    private var direction = Direction.RIGHT
    private var nextDirection = Direction.RIGHT
    private var score = 0

    var isGameOver = false
        private set

    var onScoreChanged: ((Int) -> Unit)? = null
    var startX = 0f
    var startY = 0f

    private val handler = Handler(Looper.getMainLooper())
    private val runnable = object : Runnable {
        override fun run() {
            if (!isGameOver) {
                moveSnake()
                invalidate()
                handler.postDelayed(this, 250)
            }
        }
    }

    private val paintSnake = Paint().apply { color = Color.GREEN; style = Paint.Style.FILL }
    private val paintFood = Paint().apply { color = Color.RED; style = Paint.Style.FILL }
    private val paintGrid = Paint().apply { color = Color.DKGRAY; style = Paint.Style.STROKE }
    private val paintText = Paint().apply {
        color = Color.RED
        textSize = 60f
        textAlign = Paint.Align.CENTER
        isAntiAlias = true
    }

    private val cellSize: Float
        get() = if (width > 0) width.toFloat() / columns else 1f

    private val rows: Int
        get() = if (cellSize > 0f) (height / cellSize).toInt().coerceAtLeast(1) else 1

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        handler.removeCallbacks(runnable)
        handler.postDelayed(runnable, 250)
    }

    override fun onDetachedFromWindow() {
        handler.removeCallbacks(runnable)
        super.onDetachedFromWindow()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        if (snake.any { it.y >= rows } || food.y >= rows) {
            snake = mutableListOf(Point(10, 1), Point(9, 1), Point(8, 1))
            direction = Direction.RIGHT
            nextDirection = Direction.RIGHT
        }
        generateFood()
    }

    fun setDirection(dir: Direction) {
        val opposite = when (direction) {
            Direction.UP -> Direction.DOWN
            Direction.DOWN -> Direction.UP
            Direction.LEFT -> Direction.RIGHT
            Direction.RIGHT -> Direction.LEFT
        }
        if (dir != opposite) nextDirection = dir
    }

    fun restart() {
        snake = mutableListOf(Point(10, 1), Point(9, 1), Point(8, 1))
        direction = Direction.RIGHT
        nextDirection = Direction.RIGHT
        score = 0
        isGameOver = false
        onScoreChanged?.invoke(score)
        generateFood()
        handler.removeCallbacks(runnable)
        handler.postDelayed(runnable, 250)
        invalidate()
    }

    private fun moveSnake() {
        direction = nextDirection
        val head = snake.first()
        val newHead = when (direction) {
            Direction.UP -> Point(head.x, head.y - 1)
            Direction.DOWN -> Point(head.x, head.y + 1)
            Direction.LEFT -> Point(head.x - 1, head.y)
            Direction.RIGHT -> Point(head.x + 1, head.y)
        }

        // اصطدام بالحواف أو بالجسم
        if (newHead.x < 0 || newHead.x >= columns ||
            newHead.y < 0 || newHead.y >= rows ||
            snake.contains(newHead)
        ) {
            isGameOver = true
            return
        }

        snake.add(0, newHead)

        if (newHead == food) {
            score += 10
            onScoreChanged?.invoke(score)
            generateFood()
        } else {
            snake.removeAt(snake.size - 1)
        }
    }

    private fun generateFood() {
        val maxY = rows
        if (snake.size >= columns * maxY) return
        var newFood: Point
        do {
            newFood = Point(Random.nextInt(0, columns), Random.nextInt(0, maxY))
        } while (snake.contains(newFood))
        food = newFood
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cell = cellSize
        val r = rows

        // رسم الشبكة
        for (i in 0..columns) {
            canvas.drawLine(i * cell, 0f, i * cell, r * cell, paintGrid)
        }
        for (i in 0..r) {
            canvas.drawLine(0f, i * cell, columns * cell, i * cell, paintGrid)
        }

        // رسم الأفعى
        snake.forEach { p ->
            canvas.drawRect(p.x * cell, p.y * cell, (p.x + 1) * cell, (p.y + 1) * cell, paintSnake)
        }

        // رسم الطعام
        canvas.drawRect(
            food.x * cell, food.y * cell,
            (food.x + 1) * cell, (food.y + 1) * cell,
            paintFood
        )

        if (isGameOver) {
            canvas.drawText("انتهت اللعبة!", width / 2f, height / 2f, paintText)
            canvas.drawText("المس الشاشة للإعادة", width / 2f, height / 2f + 80f, paintText)
        }
    }
}
