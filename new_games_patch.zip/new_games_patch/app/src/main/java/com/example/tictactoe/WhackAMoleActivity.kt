package com.example.tictactoe

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.GridLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import kotlin.random.Random

class WhackAMoleActivity : AppCompatActivity() {

    private lateinit var gridLayout: GridLayout
    private lateinit var scoreText: TextView
    private var score = 0
    private val buttons = mutableListOf<Button>()
    private val handler = Handler(Looper.getMainLooper())
    private var activeIndex = -1

    private val gameRunnable = object : Runnable {
        override fun run() {
            if (activeIndex != -1) buttons[activeIndex].text = ""
            activeIndex = Random.nextInt(0, buttons.size)
            buttons[activeIndex].text = "🐹"
            handler.postDelayed(this, 800)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_whack_a_mole)

        gridLayout = findViewById(R.id.gridWhack)
        scoreText = findViewById(R.id.tvWhackScore)

        for (i in 0 until 9) {
            val button = Button(this).apply {
                textSize = 32f
                setOnClickListener {
                    if (activeIndex == i) {
                        score++
                        scoreText.text = "النقاط: $score"
                        text = ""
                        activeIndex = -1
                    }
                }
            }
            val params = GridLayout.LayoutParams(
                GridLayout.spec(i / 3, 1f),
                GridLayout.spec(i % 3, 1f)
            ).apply {
                width = 0
                height = 0
                setMargins(4, 4, 4, 4)
            }
            gridLayout.addView(button, params)
            buttons.add(button)
        }
    }

    override fun onResume() {
        super.onResume()
        handler.removeCallbacks(gameRunnable)
        handler.post(gameRunnable)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(gameRunnable)
    }

    override fun onDestroy() {
        handler.removeCallbacks(gameRunnable)
        super.onDestroy()
    }
}
